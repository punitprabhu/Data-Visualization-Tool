document.getElementById('fileInput').addEventListener('change', handleFileSelect);
document.getElementById('plotButton').addEventListener('click', handlePlot);

let data = null;
let columns = [];

function handleFileSelect(event) {
    const file = event.target.files[0];
    const reader = new FileReader();

    reader.onload = function(e) {
        data = d3.csvParse(e.target.result);
        columns = Object.keys(data[0]);
        populateDropdowns(columns);
        console.log('CSV file loaded');
    };

    reader.readAsText(file);
}

function populateDropdowns(columns) {
    const xAxisSelect = document.getElementById('xAxisSelect');
    const yAxisSelect = document.getElementById('yAxisSelect');

    xAxisSelect.innerHTML = '';
    yAxisSelect.innerHTML = '';

    columns.forEach(column => {
        const option = document.createElement('option');
        option.text = column;
        option.value = column;
        xAxisSelect.add(option);
        yAxisSelect.add(option.cloneNode(true));
    });
}

function handlePlot() {
    if (data) {
        const chartType = getSelectedChartType();
        const xAxis = document.getElementById('xAxisSelect').value;
        const yAxis = document.getElementById('yAxisSelect').value;
        visualizeData(data, chartType, xAxis, yAxis);
    } else {
        console.error('No data available. Please upload a CSV file.');
    }
}

function getSelectedChartType() {
    const chartTypeButtons = document.getElementsByName('chartType');
    for (const button of chartTypeButtons) {
        if (button.checked) {
            return button.value;
        }
    }
    return null;
}

function visualizeData(data, chartType, xAxis, yAxis) {
    // Clear existing visualization
    d3.select('#visualization').html('');

    // Determine chart type and call appropriate function
    switch (chartType) {
        case 'bar':
            visualizeBarChart(data, xAxis, yAxis);
            break;
        case 'line':
            visualizeLineChart(data, xAxis, yAxis);
            break;
        case 'scatter':
            visualizeScatterPlot(data, xAxis, yAxis);
            break;
        case 'table':
            visualizeTable(data);
            break;
        default:
            console.error('Invalid chart type:', chartType);
    }
}

function visualizeBarChart(data, xAxis, yAxis) {
    const margin = { top: 20, right: 20, bottom: 30, left: 40 };
    const width = 800 - margin.left - margin.right;
    const height = 400 - margin.top - margin.bottom;

    // Group data by x-axis category and calculate the sum of y-values for each category
    const groupedData = d3.group(data, d => d[xAxis]);
    const summarizedData = Array.from(groupedData, ([key, value]) => ({
        [xAxis]: key,
        [yAxis]: d3.sum(value, d => d[yAxis])
    }));

    const svg = d3.select('#visualization')
        .append('svg')
        .attr('width', width + margin.left + margin.right)
        .attr('height', height + margin.top + margin.bottom)
        .append('g')
        .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')');

    const x = d3.scaleBand()
        .domain(summarizedData.map(d => d[xAxis]))
        .range([0, width])
        .padding(0.1);

    const y = d3.scaleLinear()
        .domain([0, d3.max(summarizedData, d => d[yAxis])])
        .range([height, 0]);

    svg.append('g')
        .attr('transform', 'translate(0,' + height + ')')
        .call(d3.axisBottom(x));

    svg.append('g')
        .call(d3.axisLeft(y));

    svg.selectAll('.bar')
        .data(summarizedData)
        .enter().append('rect')
        .attr('class', 'bar')
        .attr('x', d => x(d[xAxis]))
        .attr('width', x.bandwidth())
        .attr('y', d => y(d[yAxis]))
        .attr('height', d => height - y(d[yAxis]))
        .on('mouseover', function(d) {
            d3.select(this).attr('fill', 'orange');
        })
        .on('mouseout', function(d) {
            d3.select(this).attr('fill', 'steelblue');
        });
	  
    // Append data labels
    svg.selectAll('.bar-label')
        .data(summarizedData)
        .enter().append('text')
        .attr('class', 'bar-label')
        .attr('x', d => x(d[xAxis]) + x.bandwidth() / 2)
        .attr('y', d => y(d[yAxis]) - 5) // Adjust label position
        .attr('text-anchor', 'middle')
        .text(d => d[yAxis]);
}

function visualizeLineChart(data, xAxis, yAxis) {
    const margin = { top: 20, right: 20, bottom: 30, left: 40 };
    const width = 800 - margin.left - margin.right;
    const height = 400 - margin.top - margin.bottom;

    const svg = d3.select('#visualization')
        .append('svg')
        .attr('width', width + margin.left + margin.right)
        .attr('height', height + margin.top + margin.bottom)
        .append('g')
        .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')');

    const x = d3.scaleLinear()
        .domain(d3.extent(data, d => d[xAxis]))
        .range([0, width]);

    const y = d3.scaleLinear()
        .domain(d3.extent(data, d => d[yAxis]))
        .range([height, 0]);

    const line = d3.line()
        .x(d => x(d[xAxis]))
        .y(d => y(d[yAxis]));

    svg.append('path')
        .datum(data)
        .attr('fill', 'none')
        .attr('stroke', 'steelblue')
        .attr('stroke-width', 1.5)
        .attr('d', line)
        .on('mouseover', function(d) {
            d3.select(this).attr('stroke', 'orange');
        })
        .on('mouseout', function(d) {
            d3.select(this).attr('stroke', 'steelblue');
        });
	 svg.selectAll('.line-label')
        .data(data)
        .enter().append('text')
        .attr('class', 'line-label')
        .attr('x', (d, i) => x(d[xAxis]))
        .attr('y', (d, i) => y(d[yAxis]) - 10) // Adjust label position
        .attr('text-anchor', 'middle')
        .text(d => d[yAxis]);
}

function visualizeScatterPlot(data, xAxis, yAxis) {
    const margin = { top: 20, right: 20, bottom: 30, left: 40 };
    const width = 800 - margin.left - margin.right;
    const height = 400 - margin.top - margin.bottom;

    const svg = d3.select('#visualization')
        .append('svg')
        .attr('width', width + margin.left + margin.right)
        .attr('height', height + margin.top + margin.bottom)
        .append('g')
        .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')');

    const x = d3.scaleLinear()
        .domain(d3.extent(data, d => d[xAxis]))
        .range([0, width]);

    const y = d3.scaleLinear()
        .domain(d3.extent(data, d => d[yAxis]))
        .range([height, 0]);

    svg.selectAll('.dot')
        .data(data)
        .enter().append('circle')
        .attr('class', 'dot')
        .attr('r', 3.5)
        .attr('cx', d => x(d[xAxis]))
        .attr('cy', d => y(d[yAxis]))
        .on('mouseover', function(d) {
            d3.select(this).attr('fill', 'orange');
        })
        .on('mouseout', function(d) {
            d3.select(this).attr('fill', 'steelblue');
        });
	 svg.selectAll('.dot-label')
        .data(data)
        .enter().append('text')
        .attr('class', 'dot-label')
        .attr('x', d => x(d[xAxis]))
        .attr('y', d => y(d[yAxis]) - 10) // Adjust label position
        .attr('text-anchor', 'middle')
        .text(d => d[yAxis]);
}

function visualizeTable(data) {
    const margin = { top: 20, right: 20, bottom: 30, left: 40 };
    const width = 800 - margin.left - margin.right;
    const height = 400 - margin.top - margin.bottom;

    // Create a div container with fixed dimensions and overflow auto
    const container = d3.select('#visualization')
        .append('div')
        .style('width', width + 'px')
        .style('height', height + 'px')
        .style('overflow', 'auto');

    // Append an SVG element to the container
    const svg = container.append('svg')
        .attr('width', width + margin.left + margin.right)
        .attr('height', height + margin.top + margin.bottom)
        .append('g')
        .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')');

    // Create table element
    const table = svg.append('foreignObject')
        .attr('width', '100%')
        .attr('height', '100%')
        .append('xhtml:table')
        .attr('class', 'data-table');

    // Append table headers
    const thead = table.append('thead');
    const tbody = table.append('tbody');

    const columns = Object.keys(data[0]);
    const headers = thead.append('tr')
        .selectAll('th')
        .data(columns)
        .enter()
        .append('th')
        .text(d => d);

    // Append table rows
    const rows = tbody.selectAll('tr')
        .data(data)
        .enter()
        .append('tr');

    // Populate table cells
    const cells = rows.selectAll('td')
        .data(d => columns.map(column => ({ column, value: d[column] })))
        .enter()
        .append('td')
        .text(d => d.value);
}

function saveVisualization() {
    const svgElement = document.querySelector('#visualization svg');

    // Serialize the SVG element to XML
    const serializer = new XMLSerializer();
    const svgString = serializer.serializeToString(svgElement);

    // Create a Blob containing the SVG data
    const blob = new Blob([svgString], { type: 'image/svg+xml' });

    // Create a temporary URL for the Blob
    const url = URL.createObjectURL(blob);

    // Create a link element to trigger the download
    const link = document.createElement('a');
    link.href = url;
    link.download = 'visualization.svg'; // Set the filename
    link.click();

    // Clean up by revoking the URL
    URL.revokeObjectURL(url);
}
