const express = require('express');
const multer = require('multer');
const upload = multer({ dest: 'uploads/' });
const fs = require('fs');
const csv = require('csv-parser');
const app = express();
const port = 3000;

let uploadedData = null; // Store uploaded data in memory

app.use(express.static('public'));

app.post('/upload', upload.single('csvFile'), (req, res) => {
    if (!req.file) {
        return res.status(400).send('No files were uploaded.');
    }

    const filePath = req.file.path;
    const data = [];

    fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => {
            data.push(row);
        })
        .on('end', () => {
            // Remove the uploaded file
            fs.unlinkSync(filePath);

            // Store the uploaded data
            uploadedData = data;

            res.sendStatus(200); // Send success response
        });
});

app.get('/data', (req, res) => {
    if (!uploadedData) {
        return res.status(404).send('No data available.');
    }

    res.json(uploadedData);
});

// Serve the frontend HTML file
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});

app.listen(port, () => console.log(`Server running on http://localhost:${port}`));
